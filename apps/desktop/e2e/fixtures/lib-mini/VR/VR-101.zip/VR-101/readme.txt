lib-mini fixture
